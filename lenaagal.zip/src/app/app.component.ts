import { Component } from '@angular/core';
import * as jsonData from '../assets/data.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  constructor() {
    const json = JSON.parse(JSON.stringify(jsonData));
    if (!json || !json.data) return;
    this.data = json.data;
    const main: any = this.data.shift();
    if (main == undefined) return;
    this.data = this.shuffle(this.data);
    this.data.unshift(main);
    this.selectedObj = this.data[this.selectedIdx];
  }
  private data: any[] = [];

  private selectedIdx = 0;
  public selectedObj: any = null;
  public mute: boolean = false;

  public next() {
    this.selectedIdx++;
    if (this.selectedIdx >= this.data.length) this.selectedIdx = 0;
    this.resetAudio();
    this.selectedObj = this.data[this.selectedIdx];
  }

  public prev() {
    this.selectedIdx--;
    if (this.selectedIdx < 0) this.selectedIdx = this.data.length - 1;
    this.resetAudio();
    this.selectedObj = this.data[this.selectedIdx];
  }

  private shuffle(array: any[]) {
    let currentIndex = array.length,
      randomIndex;

    // While there remain elements to shuffle.
    while (currentIndex != 0) {
      // Pick a remaining element.
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;

      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex],
        array[currentIndex],
      ];
    }

    return array;
  }

  private resetAudio() {
    if (this.currentAudio) this.currentAudio.pause();
    this.currentAudio = null;
    this.percentage = 0;
  }

  public currentAudio: HTMLAudioElement | null = null;
  public percentage: number = 0;
  public playAudio() {
    if (!this.selectedObj || !this.selectedObj.audio) return;
    if (this.currentAudio == null) {
      this.currentAudio = new Audio(
        '../assets/audios/' + this.selectedObj.audio
      );
      this.currentAudio.addEventListener(
        'timeupdate',
        () => {
          if (!this.currentAudio) this.percentage = 0;
          else
            this.percentage = Math.floor(
              (100 / this.currentAudio.duration) * this.currentAudio.currentTime
            );
        },
        false
      );
      this.currentAudio.load();
    }
    if (this.currentAudio.paused) this.currentAudio.play();
    else this.currentAudio.pause();
  }
}
